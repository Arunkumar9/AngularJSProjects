library angular2.test.core.annotations.decorators_dart_spec;

main() {
  // not relavant for dart.
}
