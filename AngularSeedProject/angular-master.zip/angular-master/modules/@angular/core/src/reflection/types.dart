library reflection.types;

typedef SetterFn(obj, value);
typedef GetterFn(obj);
typedef MethodFn(obj, List args);
