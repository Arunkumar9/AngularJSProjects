/**
 * We don't know how to extract schema in dart, so do nothing.
 */
extractSchema(fn(List<String> descriptors)) {
}
