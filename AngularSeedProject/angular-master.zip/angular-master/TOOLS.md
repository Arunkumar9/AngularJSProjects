# Developer Tools for Angular 2

- [JavaScript](TOOLS_JS.md)
- [Dart](TOOLS_DART.md)
